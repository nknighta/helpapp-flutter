import 'package:flutter/material.dart';
import 'main.dart'; // MyHomePageState をインポート

class Map extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('マップ画面'),
      ),
      body: Container(
        color: Color.fromARGB(255, 200, 251, 255),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.chat),
            label: 'チャット',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'ホーム',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'プロフィール',
          ),
        ],
        currentIndex: 1, // マップ画面はホームの隣なのでindexは1
        onTap: (index) {
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (context) => MyHomePage(initialIndex: index)),
          );
        },
      ),
    );
  }
}
